import { describe, it, expect, beforeEach } from "vitest";
import { BaseAgent } from "./base-agent.js";
import { InMemoryArtifactStore } from "../../artifact-store/src/in-memory-store.js";
import { StubLLMAdapter } from "../../adapters/stub/src/stub-adapter.js";
import type {
  AgentMessage,
  ConsentDecision,
  ConsentRequest,
  LLMAdapter,
} from "./types.js";
import { randomUUID } from "crypto";

// ─── Concrete subclass for testing abstract BaseAgent ─────────────────────────
class EchoAgent extends BaseAgent {
  public lastMessage: AgentMessage | null = null;

  async handleMessage(msg: AgentMessage): Promise<AgentMessage> {
    this.lastMessage = msg;
    return this.reply(msg, { echoed: msg.payload });
  }
}

// ─── Helper: create a standard AgentMessage ────────────────────────────────
function makeMsg(
  overrides: Partial<AgentMessage> = {}
): AgentMessage {
  return {
    id: randomUUID(),
    from: "orchestrator",
    to: "echo-agent",
    type: "task",
    payload: { task: "do something" },
    context: { taskTreeId: "tree-1" },
    timestamp: Date.now(),
    ...overrides,
  };
}

describe("BaseAgent", () => {
  let store: InMemoryArtifactStore;
  let llm: StubLLMAdapter;
  let agent: EchoAgent;

  beforeEach(() => {
    store = new InMemoryArtifactStore();
    llm = new StubLLMAdapter("base-agent-test");
    agent = new EchoAgent({
      agentId: "echo-agent",
      role: "specialist",
      llm: llm as unknown as LLMAdapter,
      store,
      systemPrompt: "You echo everything back.",
    });
  });

  // ── 1. Construction ───────────────────────────────────────────────────────
  describe("construction", () => {
    it("exposes agentId, role, llm, tools from config", () => {
      expect(agent.agentId).toBe("echo-agent");
      expect(agent.role).toBe("specialist");
      expect(agent.tools).toEqual([]);
    });

    it("uses default system prompt when none provided", () => {
      const a = new EchoAgent({
        agentId: "auto-prompt",
        role: "orchestrator",
        llm: llm as unknown as LLMAdapter,
        store,
      });
      // handleMessage should still work (system prompt used internally)
      expect(a.agentId).toBe("auto-prompt");
    });
  });

  // ── 2. requestConsent — default policy (allow all) ─────────────────────
  describe("requestConsent (default allow-all policy)", () => {
    it("grants consent by default for any request", async () => {
      const req: ConsentRequest = {
        requestId: randomUUID(),
        requestingAgent: "any-agent",
        action: "send_message",
        justification: "just testing",
      };
      const decision = await agent.requestConsent(req);
      expect(decision).toBe("granted");
    });

    it("grants consent for write_artifact action", async () => {
      const req: ConsentRequest = {
        requestId: randomUUID(),
        requestingAgent: "writer",
        action: "write_artifact",
        justification: "writing an artifact",
      };
      expect(await agent.requestConsent(req)).toBe("granted");
    });
  });

  // ── 3. requestConsent — custom policy ─────────────────────────────────
  describe("requestConsent (custom policy)", () => {
    it("applies a custom consentPolicy correctly (deny on sensitive)", async () => {
      const restrictedAgent = new EchoAgent({
        agentId: "restricted",
        role: "gatekeeper",
        llm: llm as unknown as LLMAdapter,
        store,
        consentPolicy: (req: ConsentRequest): ConsentDecision => {
          // Only accept messages from 'orchestrator'
          return req.requestingAgent === "orchestrator" ? "granted" : "denied";
        },
      });

      const allowedReq: ConsentRequest = {
        requestId: randomUUID(),
        requestingAgent: "orchestrator",
        action: "send_message",
        justification: "from orchestrator",
      };
      expect(await restrictedAgent.requestConsent(allowedReq)).toBe("granted");

      const blockedReq: ConsentRequest = {
        requestId: randomUUID(),
        requestingAgent: "unknown-agent",
        action: "send_message",
        justification: "from unknown",
      };
      expect(await restrictedAgent.requestConsent(blockedReq)).toBe("denied");
    });

    it("supports async consent policies", async () => {
      const asyncAgent = new EchoAgent({
        agentId: "async-policy",
        role: "specialist",
        llm: llm as unknown as LLMAdapter,
        store,
        consentPolicy: async (req: ConsentRequest): Promise<ConsentDecision> => {
          await new Promise((r) => setTimeout(r, 5));
          return req.action === "spawn_agent" ? "denied" : "granted";
        },
      });

      const spawnReq: ConsentRequest = {
        requestId: randomUUID(),
        requestingAgent: "anyone",
        action: "spawn_agent",
        justification: "trying to spawn",
      };
      expect(await asyncAgent.requestConsent(spawnReq)).toBe("denied");

      const readReq: ConsentRequest = {
        requestId: randomUUID(),
        requestingAgent: "anyone",
        action: "read_artifact",
        justification: "just reading",
      };
      expect(await asyncAgent.requestConsent(readReq)).toBe("granted");
    });
  });

  // ── 4. capabilityVector ───────────────────────────────────────────────────
  describe("capabilityVector()", () => {
    it("returns a 64-dimensional vector", async () => {
      const vec = await agent.capabilityVector();
      expect(vec).toHaveLength(64);
    });

    it("is deterministic for the same system prompt", async () => {
      const v1 = await agent.capabilityVector();
      const v2 = await agent.capabilityVector();
      expect(v1).toEqual(v2);
    });

    it("differs between agents with different system prompts", async () => {
      const agentA = new EchoAgent({
        agentId: "a",
        role: "specialist",
        llm: llm as unknown as LLMAdapter,
        store,
        systemPrompt: "You are agent A specialized in summarization.",
      });
      const agentB = new EchoAgent({
        agentId: "b",
        role: "executor",
        llm: llm as unknown as LLMAdapter,
        store,
        systemPrompt: "You are agent B specialized in code execution.",
      });
      const va = await agentA.capabilityVector();
      const vb = await agentB.capabilityVector();
      expect(va).not.toEqual(vb);
    });
  });

  // ── 5. handleMessage + reply helper ──────────────────────────────────────
  describe("handleMessage() + reply()", () => {
    it("calls handleMessage and stores the message", async () => {
      const msg = makeMsg();
      const reply = await agent.handleMessage(msg);

      expect(agent.lastMessage).not.toBeNull();
      expect(agent.lastMessage!.id).toBe(msg.id);
      expect(reply.type).toBe("result");
    });

    it("reply preserves taskTreeId from original message", async () => {
      const msg = makeMsg({ context: { taskTreeId: "my-tree" } });
      const reply = await agent.handleMessage(msg);

      expect(reply.context.taskTreeId).toBe("my-tree");
    });

    it("reply routes back to the original sender", async () => {
      const msg = makeMsg({ from: "the-sender" });
      const reply = await agent.handleMessage(msg);
      expect(reply.to).toBe("the-sender");
      expect(reply.from).toBe("echo-agent");
    });

    it("reply has a new unique id", async () => {
      const msg = makeMsg();
      const reply = await agent.handleMessage(msg);
      expect(reply.id).not.toBe(msg.id);
    });

    it("handles multiple concurrent handleMessage calls", async () => {
      const msgs = Array.from({ length: 5 }, (_, i) =>
        makeMsg({ id: `msg-${i}`, payload: { n: i } })
      );

      const replies = await Promise.all(msgs.map((m) => agent.handleMessage(m)));
      expect(replies).toHaveLength(5);
      for (const r of replies) {
        expect(r.type).toBe("result");
      }
    });
  });
});
