import { describe, it, expect } from "vitest";
import { StubLLMAdapter } from "./stub-adapter.js";
import type { Message } from "../../../core/src/types.js";

describe("StubLLMAdapter", () => {
  const adapter = new StubLLMAdapter("test-stub", "[TEST]");

  // ── 1. Identity ───────────────────────────────────────────────────────────
  it("exposes the id passed to constructor", () => {
    expect(adapter.id).toBe("test-stub");
  });

  // ── 2. Embeddings ─────────────────────────────────────────────────────────
  describe("embeddings()", () => {
    it("returns a 64-dimensional vector", async () => {
      const vec = await adapter.embeddings("hello world");
      expect(vec).toHaveLength(64);
    });

    it("is deterministic — same input always produces same vector", async () => {
      const v1 = await adapter.embeddings("test sentence");
      const v2 = await adapter.embeddings("test sentence");
      expect(v1).toEqual(v2);
    });

    it("produces different vectors for different inputs", async () => {
      const v1 = await adapter.embeddings("apple");
      const v2 = await adapter.embeddings("banana");
      expect(v1).not.toEqual(v2);
    });

    it("vector is L2-normalised (norm ≈ 1)", async () => {
      const vec = await adapter.embeddings("normalisation test");
      const norm = Math.sqrt(vec.reduce((s, v) => s + v * v, 0));
      expect(norm).toBeCloseTo(1.0, 5);
    });

    it("all values are in the range [-1, 1]", async () => {
      const vec = await adapter.embeddings("range check");
      for (const v of vec) {
        expect(v).toBeGreaterThanOrEqual(-1);
        expect(v).toBeLessThanOrEqual(1);
      }
    });

    it("handles empty string without throwing", async () => {
      const vec = await adapter.embeddings("");
      expect(vec).toHaveLength(64);
    });

    it("handles very long strings without throwing", async () => {
      const vec = await adapter.embeddings("x".repeat(10_000));
      expect(vec).toHaveLength(64);
    });
  });

  // ── 3. complete() ─────────────────────────────────────────────────────────
  describe("complete()", () => {
    const messages: Message[] = [
      { role: "user", content: "What is 2+2?" },
    ];

    it("returns a CompletionResult with non-empty text", async () => {
      const result = await adapter.complete(messages);
      expect(result.text).toBeTruthy();
      expect(typeof result.text).toBe("string");
    });

    it("echoes the last user message content in the reply", async () => {
      const result = await adapter.complete(messages);
      expect(result.text).toContain("What is 2+2?");
    });

    it("includes usage statistics", async () => {
      const result = await adapter.complete(messages);
      expect(result.usage).toBeDefined();
      expect(result.usage!.promptTokens).toBeGreaterThan(0);
      expect(result.usage!.completionTokens).toBeGreaterThan(0);
    });

    it("is deterministic — same input same output", async () => {
      const r1 = await adapter.complete(messages);
      const r2 = await adapter.complete(messages);
      expect(r1.text).toBe(r2.text);
    });

    it("uses the configured replyPrefix", async () => {
      const prefixed = new StubLLMAdapter("id", "[MYPREFIX]");
      const result = await prefixed.complete(messages);
      expect(result.text).toContain("[MYPREFIX]");
    });

    it("handles empty messages array without throwing", async () => {
      const result = await adapter.complete([]);
      expect(result.text).toBeTruthy();
    });

    it("ignores tools parameter (no side effects)", async () => {
      const result = await adapter.complete(messages, [
        {
          name: "noop",
          description: "does nothing",
          inputSchema: {},
        },
      ]);
      expect(result.text).toBeTruthy();
    });
  });

  // ── 4. stream() ───────────────────────────────────────────────────────────
  describe("stream()", () => {
    it("yields delta chunks followed by a final done chunk", async () => {
      const chunks = [];
      for await (const chunk of adapter.stream([{ role: "user", content: "stream me" }])) {
        chunks.push(chunk);
      }

      const deltas = chunks.filter((c) => c.type === "delta");
      const done = chunks.filter((c) => c.type === "done");

      expect(deltas.length).toBeGreaterThan(0);
      expect(done).toHaveLength(1);
    });

    it("done chunk contains a CompletionResult", async () => {
      const chunks = [];
      for await (const chunk of adapter.stream([{ role: "user", content: "hello" }])) {
        chunks.push(chunk);
      }
      const done = chunks.find((c) => c.type === "done");
      expect(done!.result).toBeDefined();
      expect(done!.result!.text).toBeTruthy();
    });

    it("concatenated deltas match the final result text (modulo spaces)", async () => {
      const msgs: Message[] = [{ role: "user", content: "concat test" }];
      const chunks = [];
      for await (const chunk of adapter.stream(msgs)) {
        chunks.push(chunk);
      }

      const joined = chunks
        .filter((c) => c.type === "delta")
        .map((c) => c.delta ?? "")
        .join("")
        .trim();

      const done = chunks.find((c) => c.type === "done");
      expect(done!.result!.text.trim()).toBe(joined.trim());
    });
  });

  // ── 5. Multiple instances don't interfere ─────────────────────────────────
  it("two stub instances with different ids produce different embeddings", async () => {
    const a = new StubLLMAdapter("a");
    const b = new StubLLMAdapter("b");
    const va = await a.embeddings("common text");
    const vb = await b.embeddings("common text");
    // Different ids produce same embeddings (id doesn't affect embedding)
    // — but let's verify neither throws and both are 64d
    expect(va).toHaveLength(64);
    expect(vb).toHaveLength(64);
  });
});
