import { describe, it, expect, beforeEach } from "vitest";
import { InMemoryArtifactStore } from "./in-memory-store.js";

describe("InMemoryArtifactStore", () => {
  let store: InMemoryArtifactStore;

  beforeEach(() => {
    store = new InMemoryArtifactStore();
  });

  // ── 1. put / get ──────────────────────────────────────────────────────────
  describe("put / get", () => {
    it("stores an artifact and retrieves it by id", async () => {
      const artifact = await store.put({
        createdBy: "agent-A",
        taskTreeId: "tree-1",
        content: { hello: "world" },
      });

      expect(artifact.id).toBeTruthy();
      expect(artifact.status).toBe("draft");
      expect(artifact.createdAt).toBeGreaterThan(0);

      const fetched = await store.get(artifact.id);
      expect(fetched).not.toBeNull();
      expect(fetched!.id).toBe(artifact.id);
      expect(fetched!.content).toEqual({ hello: "world" });
    });

    it("returns null for unknown id", async () => {
      const result = await store.get("not-a-real-id");
      expect(result).toBeNull();
    });

    it("each put produces a unique id", async () => {
      const a1 = await store.put({ createdBy: "A", content: "x" });
      const a2 = await store.put({ createdBy: "A", content: "y" });
      expect(a1.id).not.toBe(a2.id);
    });
  });

  // ── 2. seal ───────────────────────────────────────────────────────────────
  describe("seal", () => {
    it("transitions artifact from draft to sealed", async () => {
      const art = await store.put({ createdBy: "A", content: "data" });
      const sealed = await store.seal(art.id, "A");

      expect(sealed.status).toBe("sealed");
      expect(sealed.sealedAt).toBeGreaterThan(0);
    });

    it("writes an artifact_sealed fossil when sealing", async () => {
      const art = await store.put({ createdBy: "A", content: "data" });
      await store.seal(art.id, "A");

      const fossils = await store.fossils();
      const sealFossils = fossils.filter((f) => f.event === "artifact_sealed");
      expect(sealFossils).toHaveLength(1);
      expect((sealFossils[0].payload as { artifactId: string }).artifactId).toBe(art.id);
    });

    it("throws if artifact not found", async () => {
      await expect(store.seal("bad-id", "A")).rejects.toThrow("not found");
    });

    it("throws if artifact is already sealed", async () => {
      const art = await store.put({ createdBy: "A", content: "data" });
      await store.seal(art.id, "A");
      await expect(store.seal(art.id, "A")).rejects.toThrow("already sealed");
    });
  });

  // ── 3. fossil chain ───────────────────────────────────────────────────────
  describe("fossil chain", () => {
    it("verifyChain returns true on empty chain", () => {
      expect(store.verifyChain().valid).toBe(true);
    });

    it("verifyChain returns true after multiple fossil writes", async () => {
      await store.put({ createdBy: "A", content: "x" });

      const art = await store.put({ createdBy: "B", content: "y" });
      await store.seal(art.id, "B");

      await store.fossil({
        event: "message_routed",
        agentId: "router",
        payload: { test: true },
        chainHash: "",
      });

      expect(store.verifyChain().valid).toBe(true);
    });

    it("fossils are ordered chronologically", async () => {
      const art = await store.put({ createdBy: "A", content: "a" });
      await store.seal(art.id, "A");

      const all = await store.fossils();
      for (let i = 1; i < all.length; i++) {
        expect(all[i].sealedAt).toBeGreaterThanOrEqual(all[i - 1].sealedAt);
      }
    });

    it("snapshot reports correct counts and chain validity", async () => {
      const art = await store.put({ createdBy: "A", content: "snap-test" });
      await store.seal(art.id, "A");

      const snap = store.snapshot();
      expect(snap.artifactCount).toBe(1);
      expect(snap.fossilCount).toBe(1); // seal writes one fossil
      expect(snap.chainValid).toBe(true);
    });
  });

  // ── 4. cosine vector search ───────────────────────────────────────────────
  describe("vector query", () => {
    it("returns empty array when no artifacts have embeddings", async () => {
      await store.put({ createdBy: "A", content: "no-embedding" });
      const results = await store.query([1, 0, 0], 5);
      expect(results).toHaveLength(0);
    });

    it("returns artifacts sorted by cosine similarity (highest first)", async () => {
      // art-close: embedding points in same direction as query
      const close = await store.put({
        createdBy: "A",
        content: "close",
        embedding: [1, 0, 0, 0],
      });
      // art-far: embedding points in opposite direction
      await store.put({
        createdBy: "B",
        content: "far",
        embedding: [-1, 0, 0, 0],
      });
      // art-mid: perpendicular — cosine = 0
      await store.put({
        createdBy: "C",
        content: "mid",
        embedding: [0, 1, 0, 0],
      });

      const query = [1, 0, 0, 0]; // exact match with "close"
      const results = await store.query(query, 3);

      expect(results).toHaveLength(3);
      expect(results[0].id).toBe(close.id); // closest
    });

    it("topK limits the number of results", async () => {
      for (let i = 0; i < 10; i++) {
        await store.put({
          createdBy: "A",
          content: `doc-${i}`,
          embedding: [Math.random(), Math.random()],
        });
      }
      const results = await store.query([1, 0], 3);
      expect(results.length).toBeLessThanOrEqual(3);
    });

    it("handles zero vectors gracefully (returns 0 similarity)", async () => {
      await store.put({
        createdBy: "A",
        content: "zero-vec",
        embedding: [0, 0, 0],
      });
      // Should not throw; zero-norm vectors get similarity 0
      const results = await store.query([1, 0, 0], 5);
      expect(results).toHaveLength(0); // cosine=0 for zero-norm → filtered or ordered last
    });
  });
});
